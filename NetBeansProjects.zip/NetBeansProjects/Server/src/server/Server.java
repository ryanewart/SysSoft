/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.awt.HeadlessException;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author n0781255
 */
public class Server {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
			boolean Test = true;
		
		ServerSocket server = new ServerSocket(9090);
		while (Test == true) {
			//System.out.println("Waiting for client message");
			Socket client = server.accept();
			DataInputStream inFromStream = new DataInputStream(client.getInputStream());
			String text = inFromStream.readUTF();
                        String[] result = text.split("\\s");
                        DataOutputStream OutToStream  = new DataOutputStream(client.getOutputStream());
                        if (verifyLogin(result[0],result[1])) {
                            OutToStream.writeUTF("Login Success");
                        }
                        else if (verifyLogin(result[0],result[1]) == false) {
                            OutToStream.writeUTF("Login Failure");
                        }
			//System.out.println(text);
			//WriteToFile(text);
			inFromStream.close(); 
                        OutToStream.close();
                        client.close();
			if(text.equalsIgnoreCase("exit")) break; 
							
		}
		}
        
        private static Scanner x;
        
        public static boolean verifyLogin(String username, String password) {
            
            //CHANGE FILEPATH ACCORDING TO LOGINS.TXT LOCATION ON DEVICE
        String filepath = "src/logins.txt";
        boolean loginFound = false;
        String tempUsername = "";
        String tempPassword = "";
               
        try {
            x = new Scanner(new File(filepath));
            //Sets the pattern of the scanner 
            x.useDelimiter("[,\n]");
            
            //Loops through the file checking if the login entered matches a record in the logins.txt file
            while(x.hasNext() && !loginFound){
                tempUsername = x.next();
                tempPassword = x.next();
                //Trim removes any trailing whitespace
                if(tempUsername.trim().equals(username.trim()) && tempPassword.trim().equals(password.trim())){
                    loginFound = true;
                }
            }
            x.close();           
            
        }
        catch(HeadlessException | FileNotFoundException e){
            JFrame frame = new JFrame("FileNotFound");
            JOptionPane.showMessageDialog(frame," Error: File Not Found!");
        }
            
            return loginFound;
        }
	
	public static void WriteToFile(String Message) {
		String fileName = "DataTest.txt";
		System.out.println(Message);
		try {
		FileWriter fout = new FileWriter(fileName,true);
		PrintWriter pout = new PrintWriter(fout,false);
		pout.println(Message);
		pout.close();
		}
		catch (IOException e) {
			
		}
	}
}