package server;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import static server.Server.verifyLogin;
import java.net.ServerSocket;
import java.io.IOException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author n0781255
 */
public class ClientRoutine {
    
    public  ClientRoutine (ServerSocket server) throws IOException {
                        Socket client = server.accept();
			DataInputStream inFromStream = new DataInputStream(client.getInputStream());
			String text = inFromStream.readUTF();
                        String[] result = text.split("\\s");
                        DataOutputStream OutToStream  = new DataOutputStream(client.getOutputStream());
                        if (text.length() > 0) {
                            if (verifyLogin(result[0],result[1])) {
                                OutToStream.writeUTF("Login Success");
                            }
                            else if (verifyLogin(result[0],result[1]) == false) {
                                OutToStream.writeUTF("Login Failure");
                            }
                        }
                        inFromStream.close(); 
                        OutToStream.close();
                        client.close();
}
}
